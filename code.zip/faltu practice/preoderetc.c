#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int data;
    struct Node *left;
    struct Node *right;
};

struct Node* createNode(int data)
{
    struct Node* newNode =
        (struct Node*)malloc(sizeof(struct Node));

    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;

    return newNode;
}

// PREORDER: Root Left Right
void preorder(struct Node* root)
{
    if (root == NULL)
        return;

    printf("%d ", root->data);

    preorder(root->left);

    preorder(root->right);
}

// INORDER: Left Root Right
void inorder(struct Node* root)
{
    if (root == NULL)
        return;

    inorder(root->left);

    printf("%d ", root->data);

    inorder(root->right);
}

// POSTORDER: Left Right Root
void postorder(struct Node* root)
{
    if (root == NULL)
        return;

    postorder(root->left);

    postorder(root->right);

    printf("%d ", root->data);
}

int main()
{
    /*
            1
           / \
          2   3
         / \
        4   5
    */

    struct Node* root = createNode(1);

    root->left = createNode(2);
    root->right = createNode(3);

    root->left->left = createNode(4);
    root->left->right = createNode(5);

    printf("Preorder: ");
    preorder(root);

    printf("\nInorder: ");
    inorder(root);

    printf("\nPostorder: ");
    postorder(root);

    return 0;
}

/*

Preorder: 1 2 4 5 3
Inorder: 4 2 5 1 3
Postorder: 4 5 2 3 1
*/