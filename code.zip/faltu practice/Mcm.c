#include <stdio.h>
#include <limits.h>

int main()
{
    int n;

    printf("Enter number of matrices: ");
    scanf("%d", &n);

    int p[n + 1];

    printf("Enter dimensions:\n");

    printf("For A1: ");
    scanf("%d %d", &p[0], &p[1]);

    for (int i = 2; i <= n; i++)
    {
        printf("Enter rows and columns of A%d: ",
               i);

        int rows, cols;
        scanf("%d %d", &rows, &cols);

        p[i] = cols;
    }

    int dp[n + 1][n + 1];

    for (int i = 1; i <= n; i++)
        dp[i][i] = 0;

    for (int length = 2; length <= n; length++)
    {
        for (int i = 1;
             i <= n - length + 1;
             i++)
        {
            int j = i + length - 1;

            dp[i][j] = INT_MAX;

            for (int k = i; k < j; k++)
            {
                int cost =
                    dp[i][k] +
                    dp[k + 1][j] +
                    p[i - 1] * p[k] * p[j];

                if (cost < dp[i][j])
                    dp[i][j] = cost;
            }
        }
    }

    printf("Minimum multiplication cost = %d\n",
           dp[1][n]);

    return 0;
}

/*

*/