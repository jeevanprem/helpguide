#include <stdio.h>
#include <stdlib.h>

struct Node {
    char ch;
    int freq;
    struct Node *left, *right;
};

struct Node* createNode(char ch, int freq)
{
    struct Node* node =
        (struct Node*)malloc(sizeof(struct Node));

    node->ch = ch;
    node->freq = freq;
    node->left = NULL;
    node->right = NULL;

    return node;
}

void swap(struct Node* heap[], int i, int j)
{
    struct Node* temp = heap[i];
    heap[i] = heap[j];
    heap[j] = temp;
}

void minHeapify(struct Node* heap[], int n, int i)
{
    int smallest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n &&
        heap[left]->freq < heap[smallest]->freq)
        smallest = left;

    if (right < n &&
        heap[right]->freq < heap[smallest]->freq)
        smallest = right;

    if (smallest != i)
    {
        swap(heap, i, smallest);
        minHeapify(heap, n, smallest);
    }
}

void buildHeap(struct Node* heap[], int n)
{
    for (int i = n / 2 - 1; i >= 0; i--)
        minHeapify(heap, n, i);
}

struct Node* extractMin(struct Node* heap[], int *n)
{
    struct Node* temp = heap[0];

    heap[0] = heap[*n - 1];
    (*n)--;

    minHeapify(heap, *n, 0);

    return temp;
}

void insertHeap(struct Node* heap[], int *n,
                struct Node* node)
{
    int i = (*n)++;

    heap[i] = node;

    while (i > 0)
    {
        int parent = (i - 1) / 2;

        if (heap[parent]->freq <= heap[i]->freq)
            break;

        swap(heap, parent, i);
        i = parent;
    }
}

void printCodes(struct Node* root, int code[], int top)
{
    if (root->left)
    {
        code[top] = 0;
        printCodes(root->left, code, top + 1);
    }

    if (root->right)
    {
        code[top] = 1;
        printCodes(root->right, code, top + 1);
    }

    if (!root->left && !root->right)
    {
        printf("%c : ", root->ch);

        for (int i = 0; i < top; i++)
            printf("%d", code[i]);

        printf("\n");
    }
}

int main()
{
    int n;

    printf("Enter number of characters: ");
    scanf("%d", &n);

    struct Node* heap[100];

    for (int i = 0; i < n; i++)
    {
        char ch;
        int freq;

        printf("Enter character and frequency: ");
        scanf(" %c %d", &ch, &freq);

        heap[i] = createNode(ch, freq);
    }

    buildHeap(heap, n);

    while (n > 1)
    {
        struct Node* left = extractMin(heap, &n);
        struct Node* right = extractMin(heap, &n);

        struct Node* newNode =
            createNode('$', left->freq + right->freq);

        newNode->left = left;
        newNode->right = right;

        insertHeap(heap, &n, newNode);
    }

    int code[100];

    printf("\nHuffman Codes:\n");
    printCodes(heap[0], code, 0);

    return 0;
}
/*
Enter number of characters: 5
Enter character and frequency:
A 5
B 9
C 12
D 13
E 16

Huffman Codes:
A : 1100
B : 1101
C : 100
D : 101
E : 0
*/