#include <stdio.h>

#define MAX 100

int main()
{
    int n;
    int graph[MAX][MAX];
    int visited[MAX] = {0};
    int queue[MAX];

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix:\n");

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
            scanf("%d", &graph[i][j]);
    }

    int source;

    printf("Enter starting vertex: ");
    scanf("%d", &source);

    int front = 0;
    int rear = 0;

    queue[rear++] = source;
    visited[source] = 1;

    printf("BFS: ");

    while (front < rear)
    {
        int u = queue[front++];

        printf("%d ", u);

        for (int v = 0; v < n; v++)
        {
            if (graph[u][v] == 1 &&
                visited[v] == 0)
            {
                visited[v] = 1;
                queue[rear++] = v;
            }
        }
    }

    return 0;
}


/*

Enter number of vertices: 5

0 1 1 0 0
1 0 0 1 0
1 0 0 1 1
0 1 1 0 1
0 0 1 1 0

Enter starting vertex: 0

BFS: 0 1 2 3 4
*/