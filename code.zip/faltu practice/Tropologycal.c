#include <stdio.h>

#define MAX 100

int main()
{
    int n, graph[MAX][MAX];
    int indegree[MAX] = {0};
    int queue[MAX];

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix:\n");

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d", &graph[i][j]);

            if (graph[i][j] == 1)
                indegree[j]++;
        }
    }

    int front = 0;
    int rear = 0;

    // Add vertices with indegree 0
    for (int i = 0; i < n; i++)
    {
        if (indegree[i] == 0)
            queue[rear++] = i;
    }

    int count = 0;

    printf("Topological Order: ");

    while (front < rear)
    {
        int u = queue[front++];

        printf("%d ", u);
        count++;

        for (int v = 0; v < n; v++)
        {
            if (graph[u][v] == 1)
            {
                indegree[v]--;

                if (indegree[v] == 0)
                    queue[rear++] = v;
            }
        }
    }

    if (count != n)
        printf("\nCycle exists. Topological sort not possible.");

    return 0;
}

/*
0 1 1 0
0 0 0 1
0 0 0 1
0 0 0 0


Topological Order: 0 1 2 3
*/